#!/bin/bash
# GitHub 빠른 푸시 스크립트

cd "$(dirname "$0")"

echo "🚀 GitHub에 푸시하기"
echo ""

# 원격 저장소 확인
if ! git remote get-url origin &>/dev/null; then
    echo "❌ 원격 저장소가 설정되지 않았습니다."
    git remote add origin https://github.com/k1300k/lunch-talk-recommender.git
    echo "✅ 원격 저장소 추가됨"
fi

# 저장소 생성 확인
echo "⚠️ 먼저 GitHub에서 저장소를 생성하세요:"
echo "   1. https://github.com/new 접속"
echo "   2. Repository name: lunch-talk-recommender"
echo "   3. 'Initialize this repository with a README' 체크하지 않기"
echo "   4. Create repository 클릭"
echo ""
read -p "저장소를 생성하셨나요? (y/n): " created

if [ "$created" != "y" ]; then
    echo "저장소를 먼저 생성해주세요."
    exit 1
fi

# Personal Access Token 입력
echo ""
echo "📝 Personal Access Token을 입력하세요:"
echo "   생성: https://github.com/settings/tokens"
echo "   권한: repo (전체)"
echo ""
read -sp "Token: " token
echo ""

if [ -z "$token" ]; then
    echo "❌ 토큰이 입력되지 않았습니다."
    exit 1
fi

# 푸시 실행
echo ""
echo "📤 GitHub에 푸시 중..."

# URL에 토큰 포함
git remote set-url origin "https://${token}@github.com/k1300k/lunch-talk-recommender.git"

# 푸시 실행
if git push -u origin main 2>&1; then
    echo ""
    echo "✅ 성공적으로 푸시되었습니다!"
    echo ""
    echo "📍 저장소 URL: https://github.com/k1300k/lunch-talk-recommender"
    
    # 보안을 위해 URL에서 토큰 제거
    git remote set-url origin "https://github.com/k1300k/lunch-talk-recommender.git"
    echo "✅ 원격 URL이 토큰 없이 설정되었습니다."
else
    echo ""
    echo "❌ 푸시 실패"
    echo ""
    echo "확인 사항:"
    echo "  1. 저장소가 생성되었는지 확인"
    echo "  2. 토큰이 올바른지 확인"
    echo "  3. 토큰에 'repo' 권한이 있는지 확인"
    exit 1
fi

