#!/usr/bin/env python3
"""서버 테스트 및 실행 스크립트"""
import sys
import os
from pathlib import Path

# 프로젝트 루트를 경로에 추가
project_root = Path(__file__).parent.resolve()
sys.path.insert(0, str(project_root))

print("=" * 60)
print("🔍 Small Talk Topic Recommender - 전체 점검 시작")
print("=" * 60)

# 1단계: 의존성 확인
print("\n[1단계] 의존성 확인 중...")
missing = []
dependencies = {
    "fastapi": "fastapi",
    "uvicorn": "uvicorn",
    "sqlalchemy": "sqlalchemy",
    "aiosqlite": "aiosqlite",
    "jinja2": "jinja2",
    "aiofiles": "aiofiles",
}

for module, package in dependencies.items():
    try:
        __import__(module)
        print(f"  ✅ {package}")
    except ImportError:
        print(f"  ❌ {package} (없음)")
        missing.append(package)

if missing:
    print(f"\n⚠️ 누락된 패키지: {', '.join(missing)}")
    print("설치 명령어:")
    print(f"  pip3 install --user {' '.join(missing)}")
    sys.exit(1)

print("✅ 모든 의존성이 설치되어 있습니다")

# 2단계: 데이터베이스 확인
print("\n[2단계] 데이터베이스 확인 중...")
db_file = project_root / "lunch_talk.db"
if db_file.exists():
    print(f"  ✅ 데이터베이스 파일 존재: {db_file}")
else:
    print(f"  ⚠️ 데이터베이스 파일 없음, 초기화 중...")
    try:
        import asyncio
        from src.infrastructure.database.init_db import init_db
        asyncio.run(init_db())
        print("  ✅ 데이터베이스 초기화 완료")
    except Exception as e:
        print(f"  ❌ 데이터베이스 초기화 실패: {e}")
        sys.exit(1)

# 3단계: 템플릿 파일 확인
print("\n[3단계] 템플릿 파일 확인 중...")
templates_dir = project_root / "templates"
required_templates = ["base.html", "index.html", "today.html"]
all_exist = True
for template in required_templates:
    template_file = templates_dir / template
    if template_file.exists():
        print(f"  ✅ {template}")
    else:
        print(f"  ❌ {template} (없음)")
        all_exist = False

if not all_exist:
    print("  ❌ 일부 템플릿 파일이 없습니다")
    sys.exit(1)

print("✅ 모든 템플릿 파일이 존재합니다")

# 4단계: 정적 파일 확인
print("\n[4단계] 정적 파일 확인 중...")
static_dir = project_root / "static"
required_static = ["css/style.css", "js/main.js"]
all_exist = True
for static_file in required_static:
    file_path = static_dir / static_file
    if file_path.exists():
        print(f"  ✅ {static_file}")
    else:
        print(f"  ❌ {static_file} (없음)")
        all_exist = False

if not all_exist:
    print("  ⚠️ 일부 정적 파일이 없지만 계속 진행합니다")

# 5단계: 경로 확인
print("\n[5단계] 경로 설정 확인 중...")
try:
    from src.presentation.api.main import app
    from src.presentation.api.web_routes import templates
    
    templates_path = templates.directory
    print(f"  ✅ 템플릿 경로: {templates_path}")
    if not Path(templates_path).exists():
        print(f"  ❌ 템플릿 경로가 존재하지 않습니다!")
        sys.exit(1)
        
    print(f"  ✅ FastAPI 앱 생성 성공")
except Exception as e:
    print(f"  ❌ 경로 설정 오류: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# 6단계: 서버 실행
print("\n[6단계] 서버 실행 준비 완료!")
print("=" * 60)
print("🚀 서버를 시작합니다...")
print("=" * 60)
print("\n📍 브라우저에서 다음 주소로 접속하세요:")
print("   - 메인 페이지: http://localhost:8000/")
print("   - 오늘의 주제: http://localhost:8000/today")
print("   - API 문서: http://localhost:8000/docs")
print("\n서버를 종료하려면 Ctrl+C를 누르세요")
print("=" * 60 + "\n")

try:
    import uvicorn
    
    # macOS에서 브라우저 자동 열기
    import subprocess
    import threading
    import time
    
    def open_browser():
        time.sleep(2)
        if sys.platform == "darwin":
            subprocess.Popen(["open", "http://localhost:8000"])
    
    threading.Thread(target=open_browser, daemon=True).start()
    
    uvicorn.run(
        "src.presentation.api.main:app",
        host="127.0.0.1",
        port=8000,
        reload=False,
        log_level="info",
    )
except KeyboardInterrupt:
    print("\n\n서버를 종료합니다...")
except Exception as e:
    print(f"\n❌ 서버 실행 오류: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

