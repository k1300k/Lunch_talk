# 🗣️ Small Talk Topic Recommender Service

직장인들을 위한 AI 기반 스몰톡 주제 추천 서비스

## 📋 프로젝트 개요

점심시간에 자연스럽고 부담 없는 대화 주제를 제공하기 위한 AI Agent 기반 웹 서비스입니다.

### 주요 기능

- **자동 주제 생성**: AI Agent가 매일 오전 9시에 새로운 스몰톡 주제 자동 생성
- **부담 없는 주제**: 정치, 종교 등 민감한 주제를 피한 안전한 대화 주제 제공
- **트렌드 반영**: 20~40대 직장인에게 적합한 주제 추천

### 기술 스택

- **Framework**: FastAPI
- **Frontend**: Jinja2 Templates (HTML/CSS/JavaScript)
- **Database**: SQLite (확장 가능)
- **AI**: OpenAI API
- **Architecture**: Clean Architecture

## 🚀 시작하기

### 1. 환경 설정

```bash
# 가상환경 생성
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 의존성 설치
pip install -r requirements.txt

# 환경 변수 설정
cp env.example .env
# .env 파일을 열어 OPENAI_API_KEY를 설정하세요
```

### 2. 데이터베이스 초기화

```bash
# 방법 1: 직접 실행
python -m src.infrastructure.database.init_db

# 방법 2: Makefile 사용
make init-db

# 방법 3: Alembic 마이그레이션 (선택사항)
alembic revision --autogenerate -m "Initial migration"
alembic upgrade head
```

### 3. 서버 실행

```bash
# 방법 1: uvicorn 직접 실행
uvicorn src.presentation.api.main:app --reload

# 방법 2: main.py 실행
python src/main.py
```

서버가 실행되면 `http://localhost:8000`에서 웹 인터페이스를 사용할 수 있습니다.

### 웹 인터페이스

- **메인 페이지**: `http://localhost:8000/` - 활성 주제 목록 및 새 주제 생성
- **오늘의 주제**: `http://localhost:8000/today` - 오늘 생성된 주제 확인

### API 문서

- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## 📡 API 엔드포인트

### 주제 생성
```bash
POST /api/topics/generate
{
  "count": 5  # 생성할 주제 개수 (선택, 기본값: 5)
}
```

### 활성 주제 조회
```bash
GET /api/topics/active?limit=10  # limit은 선택사항
```

### 오늘의 주제 조회
```bash
GET /api/topics/today
```

## 📁 프로젝트 구조

```
lunch-talk/
├── src/
│   ├── domain/          # 도메인 레이어 (비즈니스 로직)
│   ├── application/     # 애플리케이션 레이어 (Use Cases)
│   ├── infrastructure/  # 인프라 레이어 (외부 의존성)
│   └── presentation/    # 프레젠테이션 레이어 (API)
├── tests/               # 테스트 코드
└── alembic/             # 데이터베이스 마이그레이션
```

## 🧪 테스트 실행

```bash
# 방법 1: Makefile 사용
make test          # 기본 테스트 실행
make test-cov      # 커버리지 포함 테스트 실행

# 방법 2: pytest 직접 실행
pytest tests/ -v                           # 상세 출력
pytest tests/domain/test_topic.py          # 특정 테스트 파일
pytest tests/ --cov=src --cov-report=html  # 커버리지 포함 (HTML 보고서 생성)
```

테스트 커버리지는 최소 70% 이상을 유지하도록 설정되어 있습니다.

## 🎯 주요 기능 설명

### 1. 자동 주제 생성 (스케줄러)

서버가 시작되면 자동으로 스케줄러가 활성화되며, 매일 오전 9시에 새로운 주제를 생성합니다. 
스케줄러 초기화 실패 시에도 API는 정상적으로 작동합니다.

### 2. 안전 필터링

모든 생성된 주제는 자동으로 민감한 키워드(정치, 종교 등)를 검사하여 안전한 주제만 저장됩니다.

### 3. Clean Architecture

프로젝트는 Clean Architecture 원칙에 따라 설계되어 있어, 각 레이어가 독립적으로 테스트 가능하고 유지보수가 용이합니다.

## 🛠️ 유틸리티

### Makefile 명령어

```bash
make install    # 의존성 설치
make init-db    # 데이터베이스 초기화
make test       # 테스트 실행
make test-cov   # 커버리지 포함 테스트
make run        # 서버 실행
make clean      # 임시 파일 정리
```

## 📊 프로젝트 구조 상세

```
lunch-talk/
├── alembic/              # 데이터베이스 마이그레이션
│   ├── versions/         # 마이그레이션 파일
│   ├── env.py            # Alembic 환경 설정
│   └── script.py.mako    # 마이그레이션 템플릿
├── scripts/              # 유틸리티 스크립트
│   └── init_db.py        # DB 초기화 스크립트
├── src/
│   ├── domain/           # 도메인 레이어
│   │   ├── entities/     # 엔티티
│   │   ├── repositories/ # 저장소 인터페이스
│   │   └── services/     # 도메인 서비스 인터페이스
│   ├── application/     # 애플리케이션 레이어
│   │   └── use_cases/    # Use Cases
│   ├── infrastructure/   # 인프라 레이어
│   │   ├── ai_agent/     # AI Agent 구현
│   │   ├── database/     # 데이터베이스 설정
│   │   ├── repositories/ # 저장소 구현
│   │   └── scheduler/    # 스케줄러
│   ├── presentation/     # 프레젠테이션 레이어
│   │   └── api/          # FastAPI 라우터
│   └── utils/            # 유틸리티
├── tests/                # 테스트 코드
├── .coveragerc           # 커버리지 설정
├── alembic.ini           # Alembic 설정
├── pytest.ini            # pytest 설정
└── Makefile              # Make 명령어
```

