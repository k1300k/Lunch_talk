# 📤 GitHub에 간단히 올리기

## 🚀 방법 1: 스크립트 사용 (가장 간단)

터미널에서 실행:

```bash
cd "/Users/john/lunch talk"
./auto_push.sh
```

스크립트가 자동으로:
1. 저장소 확인 안내
2. Personal Access Token 입력 요청
3. GitHub에 푸시

## 🔑 Personal Access Token 생성

1. **토큰 생성 페이지**: https://github.com/settings/tokens
2. **"Generate new token (classic)"** 클릭
3. **Token name**: `lunch-talk-recommender`
4. **Expiration**: 원하는 기간 선택
5. **권한 선택**: `repo` (전체 선택)
6. **"Generate token"** 클릭
7. **토큰 복사** (한 번만 표시!)

## 📋 저장소 생성 (아직 없다면)

1. **저장소 생성**: https://github.com/new
2. **Repository name**: `lunch-talk-recommender`
3. **Description**: `Small Talk Topic Recommender Service`
4. **Public** 또는 **Private** 선택
5. ⚠️ **"Initialize this repository with a README" 체크하지 않기**
6. **"Create repository"** 클릭

## ✅ 푸시 완료 후

저장소 URL:
**https://github.com/k1300k/lunch-talk-recommender**

## 🔄 이후 업데이트

```bash
git add .
git commit -m "변경 사항"
git push
```

