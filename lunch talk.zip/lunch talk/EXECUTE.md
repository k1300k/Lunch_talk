# ⚡ 서버 실행 가이드

## 🚀 빠른 실행

### 방법 1: run.py 사용 (가장 간단)

터미널을 열고 다음을 실행:

```bash
cd "/Users/john/lunch talk"
python3 run.py
```

### 방법 2: src/main.py 사용

```bash
cd "/Users/john/lunch talk"
python3 src/main.py
```

### 방법 3: uvicorn 직접 실행

```bash
cd "/Users/john/lunch talk"
export PYTHONPATH="/Users/john/lunch talk:$PYTHONPATH"
uvicorn src.presentation.api.main:app --host 127.0.0.1 --port 8000
```

## ✅ 실행 확인

서버가 성공적으로 실행되면:

1. 터미널에 다음과 같은 메시지가 표시됩니다:
   ```
   INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
   ```

2. 브라우저에서 접속:
   - **메인 페이지**: http://localhost:8000/
   - **오늘의 주제**: http://localhost:8000/today
   - **API 문서**: http://localhost:8000/docs

## 🔍 문제 해결

### 서버가 시작되지 않을 때

1. **의존성 설치 확인**:
   ```bash
   pip3 install --user fastapi uvicorn sqlalchemy aiosqlite jinja2 aiofiles
   ```

2. **데이터베이스 초기화**:
   ```bash
   python3 -m src.infrastructure.database.init_db
   ```

3. **포트 확인**:
   ```bash
   lsof -ti:8000
   ```
   이미 사용 중이면 다른 포트 사용:
   ```bash
   uvicorn src.presentation.api.main:app --port 8001
   ```

## 🛑 서버 종료

터미널에서 `Ctrl+C`를 누르세요.

