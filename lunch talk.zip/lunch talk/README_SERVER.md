# 🚀 서버 실행 방법

## ✅ 권장 방법: run.py 사용

터미널에서 다음 명령어를 실행하세요:

```bash
python3 run.py
```

이 스크립트가 자동으로:
- ✅ 의존성 확인
- ✅ 데이터베이스 초기화 (필요시)
- ✅ PYTHONPATH 설정
- ✅ 서버 시작
- ✅ 브라우저 자동 열기 (macOS)

## 🔧 문제 발생 시

### 1. 의존성 설치

```bash
pip3 install --user fastapi uvicorn sqlalchemy aiosqlite jinja2 aiofiles pydantic pydantic-settings python-dotenv apscheduler
```

### 2. PYTHONPATH 설정 후 실행

```bash
export PYTHONPATH="/Users/john/lunch talk:$PYTHONPATH"
python3 run.py
```

### 3. 직접 uvicorn 실행

```bash
export PYTHONPATH="/Users/john/lunch talk:$PYTHONPATH"
uvicorn src.presentation.api.main:app --host 127.0.0.1 --port 8000
```

## 📍 접속 주소

서버가 실행되면:

- **메인 페이지**: http://localhost:8000/
- **오늘의 주제**: http://localhost:8000/today  
- **API 문서**: http://localhost:8000/docs

## 🛑 서버 종료

서버가 실행 중인 터미널에서 `Ctrl+C`를 누르세요.

