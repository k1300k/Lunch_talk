# 🗣️ Small Talk Topic Recommender Service

직장인들을 위한 AI 기반 스몰톡 주제 추천 서비스

[![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.109-green.svg)](https://fastapi.tiangolo.com/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

## ✨ 주요 기능

- 🤖 **AI 기반 주제 생성**: OpenAI GPT-4를 활용한 스몰톡 주제 자동 생성
- ⏰ **자동 스케줄링**: 매일 오전 9시에 새로운 주제 자동 생성
- 🛡️ **안전 필터링**: 정치, 종교 등 민감한 주제 자동 필터링
- 🌐 **웹 인터페이스**: 직관적인 웹 UI 제공
- 📊 **REST API**: Swagger UI를 통한 API 문서 자동 생성

## 🚀 빠른 시작

### 1. 저장소 클론

```bash
git clone https://github.com/k1300k/lunch-talk-recommender.git
cd lunch-talk-recommender
```

### 2. 의존성 설치

```bash
pip install -r requirements.txt
```

### 3. 환경 변수 설정

```bash
cp env.example .env
# .env 파일을 열어 OPENAI_API_KEY 설정
```

### 4. 데이터베이스 초기화

```bash
python -m src.infrastructure.database.init_db
```

### 5. 서버 실행

```bash
python src/main.py
```

브라우저에서 http://localhost:8000 접속

## 📚 문서

- [README.md](README.md) - 전체 프로젝트 문서
- [QUICKSTART.md](QUICKSTART.md) - 빠른 시작 가이드
- [ARCHITECTURE.md](ARCHITECTURE.md) - 아키텍처 문서

## 🏗️ 기술 스택

- **Backend**: FastAPI
- **Frontend**: Jinja2 Templates
- **Database**: SQLite (Alembic 마이그레이션 지원)
- **AI**: OpenAI API
- **Architecture**: Clean Architecture

## 📄 라이선스

MIT License

