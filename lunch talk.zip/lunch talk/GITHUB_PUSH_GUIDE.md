# 🚀 GitHub에 푸시하기 - 상세 가이드

## 현재 상태

✅ 로컬 Git 저장소 초기화 완료
✅ 모든 파일 커밋 완료
✅ 원격 저장소 연결 완료: `https://github.com/k1300k/lunch-talk-recommender.git`
⚠️ GitHub 인증 필요

## 📋 단계별 가이드

### 1단계: GitHub 저장소 생성

만약 저장소가 아직 없다면:

1. https://github.com/new 접속
2. **Repository name**: `lunch-talk-recommender`
3. **Description**: `Small Talk Topic Recommender Service - AI 기반 스몰톡 주제 추천 서비스`
4. **Public** 또는 **Private** 선택
5. ⚠️ **중요**: "Initialize this repository with a README" 체크하지 않기
6. "Create repository" 클릭

### 2단계: Personal Access Token 생성

GitHub는 비밀번호 인증을 지원하지 않으므로 Personal Access Token이 필요합니다:

1. https://github.com/settings/tokens 접속
2. "Generate new token" → "Generate new token (classic)" 클릭
3. **Token name**: `lunch-talk-recommender`
4. **Expiration**: 원하는 기간 선택 (예: 90 days)
5. **권한 선택**: `repo` (전체 선택)
   - repo (전체)
     - repo:status
     - repo_deployment
     - public_repo
     - repo:invite
     - security_events
6. "Generate token" 클릭
7. **토큰 복사** (한 번만 표시되므로 즉시 복사!)

### 3단계: Git Credential Helper 설정 (선택사항)

토큰을 매번 입력하지 않으려면:

```bash
# macOS Keychain 사용
git config --global credential.helper osxkeychain

# 또는 캐시에 저장 (1시간)
git config --global credential.helper 'cache --timeout=3600'
```

### 4단계: 푸시 실행

터미널에서 다음 명령어 실행:

```bash
cd "/Users/john/lunch talk"
git push -u origin main
```

**비밀번호 입력 시**: 
- Username: `k1300k`
- Password: **Personal Access Token** (비밀번호가 아님!)

### 5단계: SSH 사용 (대안 - 권장)

Personal Access Token 대신 SSH를 사용할 수 있습니다:

#### SSH 키 생성 (이미 있다면 스킵)

```bash
ssh-keygen -t ed25519 -C "your_email@example.com"
# Enter 키 두 번 (비밀번호 없음)
```

#### SSH 키를 GitHub에 추가

```bash
# 공개 키 복사
cat ~/.ssh/id_ed25519.pub
```

1. 복사한 키를 https://github.com/settings/keys 에 추가
2. "New SSH key" 클릭
3. Title: `MacBook Air` (또는 원하는 이름)
4. Key: 복사한 키 붙여넣기
5. "Add SSH key" 클릭

#### 원격 저장소 URL을 SSH로 변경

```bash
cd "/Users/john/lunch talk"
git remote set-url origin git@github.com:k1300k/lunch-talk-recommender.git
git push -u origin main
```

## ✅ 확인

푸시 완료 후 다음 URL에서 확인:
**https://github.com/k1300k/lunch-talk-recommender**

## 🔄 이후 업데이트

파일을 수정한 후:

```bash
git add .
git commit -m "변경 사항 설명"
git push
```

## 📝 현재 커밋 상태

```bash
git log --oneline -3
```

3개의 커밋이 준비되어 있습니다:
1. Initial commit: Small Talk Topic Recommender Service
2. Add GitHub setup guide and CI workflow
3. Add deployment guide

