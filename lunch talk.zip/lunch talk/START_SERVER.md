# 🚀 서버 실행 가이드

## 빠른 실행 방법

### 방법 1: 자동 점검 스크립트 (권장)

터미널에서 다음 명령어 실행:

```bash
python3 check_and_run.py
```

이 스크립트가 자동으로:
- ✅ 의존성 확인
- ✅ 데이터베이스 초기화
- ✅ 파일 경로 확인
- ✅ 서버 시작

### 방법 2: 직접 실행

```bash
python3 src/main.py
```

### 방법 3: Uvicorn 직접 실행

```bash
uvicorn src.presentation.api.main:app --reload --host 127.0.0.1 --port 8000
```

## 접속 주소

서버가 실행되면 브라우저에서 접속:

- **메인 페이지**: http://localhost:8000/
- **오늘의 주제**: http://localhost:8000/today
- **API 문서**: http://localhost:8000/docs

## 문제 해결

### 포트가 이미 사용 중일 때

다른 포트로 실행:

```bash
uvicorn src.presentation.api.main:app --port 8001
```

### 의존성 설치 오류 시

```bash
pip3 install --user fastapi uvicorn sqlalchemy aiosqlite jinja2 aiofiles pydantic pydantic-settings python-dotenv
```

### 데이터베이스 초기화

```bash
python3 -m src.infrastructure.database.init_db
```

## 로그 확인

서버가 실행되면 콘솔에 로그가 출력됩니다. 오류가 발생하면 로그를 확인하세요.

