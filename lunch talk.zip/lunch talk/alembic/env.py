"""Alembic 마이그레이션 환경 설정"""
import asyncio
from logging.config import fileConfig
from sqlalchemy import pool
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import async_engine_from_config

from alembic import context

# 이 부분을 프로젝트의 Base와 설정에 맞게 수정해야 합니다
import sys
from pathlib import Path

# 프로젝트 루트를 sys.path에 추가
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.infrastructure.database.models import Base
from pydantic_settings import BaseSettings


class DatabaseSettings(BaseSettings):
    """데이터베이스 설정"""
    database_url: str = "sqlite:///./lunch_talk.db"
    
    class Config:
        env_file = ".env"
        env_prefix = "DATABASE_"


def get_database_url_for_alembic() -> str:
    """Alembic용 데이터베이스 URL 가져오기 (sync URL)"""
    settings = DatabaseSettings()
    return settings.database_url  # Alembic은 sync URL 필요


# Alembic 설정 객체
config = context.config

# SQLAlchemy URL 설정
database_url = get_database_url_for_alembic()
config.set_main_option("sqlalchemy.url", database_url)

# 로깅 설정 해석
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# 메타데이터 설정
target_metadata = Base.metadata

# 버전 테이블 이름
# version_locations = config.get_main_option("version_locations")


def run_migrations_offline() -> None:
    """Offline 모드에서 마이그레이션 실행"""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection: Connection) -> None:
    """마이그레이션 실행"""
    context.configure(connection=connection, target_metadata=target_metadata)

    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations() -> None:
    """비동기 마이그레이션 실행"""
    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)

    await connectable.dispose()


def run_migrations_online() -> None:
    """Online 모드에서 마이그레이션 실행"""
    asyncio.run(run_async_migrations())


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()

