from abc import ABC, abstractmethod
from datetime import datetime
from typing import Optional, List
from ..entities.topic import Topic


class TopicRepository(ABC):
    """주제 저장소 인터페이스"""
    
    @abstractmethod
    async def create(self, topic: Topic) -> Topic:
        """주제 생성"""
        pass
    
    @abstractmethod
    async def get_by_id(self, topic_id: int) -> Optional[Topic]:
        """ID로 주제 조회"""
        pass
    
    @abstractmethod
    async def get_active_topics(self, limit: Optional[int] = None) -> List[Topic]:
        """활성화된 주제 목록 조회"""
        pass
    
    @abstractmethod
    async def get_topics_by_date(self, date: datetime) -> List[Topic]:
        """특정 날짜의 주제 목록 조회"""
        pass
    
    @abstractmethod
    async def update(self, topic: Topic) -> Topic:
        """주제 업데이트"""
        pass
    
    @abstractmethod
    async def deactivate_old_topics(self, before_date: datetime) -> int:
        """특정 날짜 이전의 주제들을 비활성화"""
        pass

