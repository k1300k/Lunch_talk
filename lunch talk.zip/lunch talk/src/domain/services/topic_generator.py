from abc import ABC, abstractmethod
from typing import List
from ..entities.topic import Topic


class TopicGenerator(ABC):
    """주제 생성기 인터페이스"""
    
    @abstractmethod
    async def generate_topics(self, count: int = 5) -> List[Topic]:
        """
        스몰톡 주제 생성
        
        Args:
            count: 생성할 주제 개수
            
        Returns:
            생성된 주제 리스트
        """
        pass

