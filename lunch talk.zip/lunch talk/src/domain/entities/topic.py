from datetime import datetime
from typing import Optional
from dataclasses import dataclass


@dataclass
class Topic:
    """스몰톡 주제 엔티티"""
    
    id: Optional[int]
    title: str
    description: str
    category: str
    tags: list[str]
    created_at: datetime
    is_active: bool
    
    def __post_init__(self):
        """엔티티 생성 후 유효성 검증"""
        if not self.title or not self.title.strip():
            raise ValueError("제목은 필수입니다")
        if not self.description or not self.description.strip():
            raise ValueError("설명은 필수입니다")
        if not self.category or not self.category.strip():
            raise ValueError("카테고리는 필수입니다")
        if self.tags is None:
            self.tags = []
    
    def deactivate(self) -> None:
        """주제를 비활성화"""
        self.is_active = False
    
    def activate(self) -> None:
        """주제를 활성화"""
        self.is_active = True
    
    def is_safe(self) -> bool:
        """민감한 주제인지 확인 (정치, 종교 등)"""
        unsafe_keywords = ["정치", "종교", "선거", "투표", "당파", "교회", "사원"]
        text = f"{self.title} {self.description}".lower()
        return not any(keyword in text for keyword in unsafe_keywords)

