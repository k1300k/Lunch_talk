from contextlib import asynccontextmanager
import logging
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.staticfiles import StaticFiles

from .routes import router
from .web_routes import router as web_router
from .exception_handlers import (
    validation_exception_handler,
    general_exception_handler,
)
from ....infrastructure.scheduler.topic_scheduler import TopicScheduler

logger = logging.getLogger(__name__)
_scheduler: TopicScheduler = None

# 정적 파일 및 템플릿 경로 설정
# main.py 위치: src/presentation/api/main.py
# static/templates 위치: 프로젝트 루트/static, 프로젝트 루트/templates
# Path 계산: src/presentation/api/main.py -> src/presentation/api -> src/presentation -> src -> 프로젝트 루트
_current_file = Path(__file__).resolve()
BASE_DIR = _current_file.parent.parent.parent.parent
static_dir = BASE_DIR / "static"
templates_dir = BASE_DIR / "templates"

logger.info(f"Static 디렉토리: {static_dir}, 존재: {static_dir.exists()}")
logger.info(f"Templates 디렉토리: {templates_dir}, 존재: {templates_dir.exists()}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """애플리케이션 생명주기 관리"""
    # 시작 시
    global _scheduler
    try:
        _scheduler = TopicScheduler()
        _scheduler.start()
        logger.info("스케줄러가 시작되었습니다.")
    except Exception as e:
        logger.warning(f"스케줄러 시작 실패: {e}. API는 정상 작동하지만 자동 주제 생성이 비활성화됩니다.")
    
    yield
    
    # 종료 시
    if _scheduler:
        try:
            _scheduler.shutdown()
            logger.info("스케줄러가 종료되었습니다.")
        except Exception as e:
            logger.error(f"스케줄러 종료 중 오류 발생: {e}")


app = FastAPI(
    title="Small Talk Topic Recommender",
    description="직장인들을 위한 AI 기반 스몰톡 주제 추천 서비스",
    version="1.0.0",
    lifespan=lifespan,
)

# 예외 핸들러 등록
app.add_exception_handler(RequestValidationError, validation_exception_handler)
app.add_exception_handler(Exception, general_exception_handler)

# 라우터 등록 (웹 라우터를 먼저 등록하여 루트 경로 매칭 우선)
app.include_router(web_router)  # 웹 UI 라우터
app.include_router(router)  # API 라우터

# 정적 파일 서빙
if static_dir.exists():
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


# 루트 엔드포인트는 웹 라우터로 이동

