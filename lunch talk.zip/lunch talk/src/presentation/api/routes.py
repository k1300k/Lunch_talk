from typing import Optional
import logging
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from .schemas import (
    TopicResponse,
    TopicsResponse,
    GenerateTopicsRequest,
)
from .dependencies import (
    get_db_session_dependency,
    get_topic_generator,
    get_generate_topics_use_case,
    get_get_active_topics_use_case,
    get_get_today_topics_use_case,
)
from ...application.use_cases.generate_topics import GenerateTopicsUseCase
from ...application.use_cases.get_active_topics import GetActiveTopicsUseCase
from ...application.use_cases.get_today_topics import GetTodayTopicsUseCase

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/topics", tags=["topics"])


@router.post("/generate", response_model=TopicsResponse)
async def generate_topics(
    request: GenerateTopicsRequest,
    session: AsyncSession = Depends(get_db_session_dependency),
    generator = Depends(get_topic_generator),
    use_case: GenerateTopicsUseCase = Depends(get_generate_topics_use_case),
):
    """주제 생성"""
    try:
        if request.count and (request.count < 1 or request.count > 20):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="주제 개수는 1~20 사이여야 합니다."
            )
        
        topics = await use_case.execute(count=request.count or 5)
        
        return TopicsResponse(
            topics=[TopicResponse(**topic.__dict__) for topic in topics],
            count=len(topics),
        )
    except ValueError as e:
        logger.error(f"주제 생성 실패: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"주제 생성 중 오류 발생: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="주제 생성 중 오류가 발생했습니다."
        )


@router.get("/active", response_model=TopicsResponse)
async def get_active_topics(
    limit: Optional[int] = None,
    session: AsyncSession = Depends(get_db_session_dependency),
    use_case: GetActiveTopicsUseCase = Depends(get_get_active_topics_use_case),
):
    """활성화된 주제 목록 조회"""
    try:
        if limit and (limit < 1 or limit > 100):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="limit은 1~100 사이여야 합니다."
            )
        
        topics = await use_case.execute(limit=limit)
        
        return TopicsResponse(
            topics=[TopicResponse(**topic.__dict__) for topic in topics],
            count=len(topics),
        )
    except Exception as e:
        logger.error(f"활성 주제 조회 중 오류 발생: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="주제 조회 중 오류가 발생했습니다."
        )


@router.get("/today", response_model=TopicsResponse)
async def get_today_topics(
    session: AsyncSession = Depends(get_db_session_dependency),
    use_case: GetTodayTopicsUseCase = Depends(get_get_today_topics_use_case),
):
    """오늘의 주제 조회"""
    try:
        topics = await use_case.execute()
        
        return TopicsResponse(
            topics=[TopicResponse(**topic.__dict__) for topic in topics],
            count=len(topics),
        )
    except Exception as e:
        logger.error(f"오늘의 주제 조회 중 오류 발생: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="주제 조회 중 오류가 발생했습니다."
        )

