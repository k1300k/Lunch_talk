from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import AsyncSession

from ....infrastructure.database.session import get_db_session
from ....infrastructure.repositories.topic_repository_impl import TopicRepositoryImpl
from ....infrastructure.ai_agent.openai_topic_generator import OpenAITopicGenerator
from ....application.use_cases.generate_topics import GenerateTopicsUseCase
from ....application.use_cases.get_active_topics import GetActiveTopicsUseCase
from ....application.use_cases.get_today_topics import GetTodayTopicsUseCase


async def get_db_session_dependency() -> AsyncGenerator[AsyncSession, None]:
    """데이터베이스 세션 의존성"""
    async for session in get_db_session():
        yield session


async def get_topic_repository(
    session: AsyncSession,
) -> TopicRepositoryImpl:
    """주제 저장소 의존성"""
    return TopicRepositoryImpl(session)


async def get_topic_generator() -> OpenAITopicGenerator:
    """주제 생성기 의존성"""
    try:
        return OpenAITopicGenerator()
    except ValueError as e:
        from fastapi import HTTPException, status
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"AI 서비스 설정 오류: {str(e)}. OPENAI_API_KEY를 확인하세요."
        )


async def get_generate_topics_use_case(
    session: AsyncSession,
    generator: OpenAITopicGenerator,
) -> GenerateTopicsUseCase:
    """주제 생성 Use Case 의존성"""
    repository = TopicRepositoryImpl(session)
    return GenerateTopicsUseCase(
        topic_generator=generator,
        topic_repository=repository,
    )


async def get_get_active_topics_use_case(
    session: AsyncSession,
) -> GetActiveTopicsUseCase:
    """활성 주제 조회 Use Case 의존성"""
    repository = TopicRepositoryImpl(session)
    return GetActiveTopicsUseCase(topic_repository=repository)


async def get_get_today_topics_use_case(
    session: AsyncSession,
) -> GetTodayTopicsUseCase:
    """오늘의 주제 조회 Use Case 의존성"""
    repository = TopicRepositoryImpl(session)
    return GetTodayTopicsUseCase(topic_repository=repository)

