from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel


class TopicResponse(BaseModel):
    """주제 응답 스키마"""
    id: int
    title: str
    description: str
    category: str
    tags: List[str]
    created_at: datetime
    is_active: bool
    
    class Config:
        from_attributes = True


class TopicsResponse(BaseModel):
    """주제 목록 응답 스키마"""
    topics: List[TopicResponse]
    count: int


class GenerateTopicsRequest(BaseModel):
    """주제 생성 요청 스키마"""
    count: Optional[int] = 5

