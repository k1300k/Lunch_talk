"""웹 UI 라우터"""
from pathlib import Path
from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.ext.asyncio import AsyncSession
import logging

from .dependencies import (
    get_db_session_dependency,
    get_get_active_topics_use_case,
    get_get_today_topics_use_case,
)
from ...application.use_cases.get_active_topics import GetActiveTopicsUseCase
from ...application.use_cases.get_today_topics import GetTodayTopicsUseCase

logger = logging.getLogger(__name__)
router = APIRouter(tags=["web"])

# 템플릿 디렉토리 설정
# web_routes.py 위치: src/presentation/api/web_routes.py
# templates 위치: 프로젝트 루트/templates
# Path 계산: src/presentation/api/web_routes.py -> src/presentation/api -> src/presentation -> src -> 프로젝트 루트
_current_file = Path(__file__).resolve()
BASE_DIR = _current_file.parent.parent.parent.parent
templates_dir = BASE_DIR / "templates"

# 디렉토리 존재 확인
if not templates_dir.exists():
    logger.error(f"템플릿 디렉토리를 찾을 수 없습니다: {templates_dir}")
    raise FileNotFoundError(f"템플릿 디렉토리를 찾을 수 없습니다: {templates_dir}")

logger.info(f"템플릿 디렉토리: {templates_dir}")
templates = Jinja2Templates(directory=str(templates_dir))


@router.get("/", response_class=HTMLResponse)
async def index(
    request: Request,
    session: AsyncSession = Depends(get_db_session_dependency),
    use_case: GetActiveTopicsUseCase = Depends(get_get_active_topics_use_case),
):
    """메인 페이지 - 활성 주제 목록"""
    try:
        topics = await use_case.execute(limit=10)
        
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "topics": [
                    {
                        "id": topic.id,
                        "title": topic.title,
                        "description": topic.description,
                        "category": topic.category,
                        "tags": topic.tags,
                        "created_at": topic.created_at.strftime("%Y-%m-%d %H:%M") if topic.created_at else "",
                    }
                    for topic in topics
                ],
                "count": len(topics),
            }
        )
    except Exception as e:
        logger.error(f"메인 페이지 렌더링 오류: {e}", exc_info=True)
        # 에러 발생 시 빈 페이지라도 반환
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "topics": [],
                "count": 0,
            }
        )


@router.get("/today", response_class=HTMLResponse)
async def today(
    request: Request,
    session: AsyncSession = Depends(get_db_session_dependency),
    use_case: GetTodayTopicsUseCase = Depends(get_get_today_topics_use_case),
):
    """오늘의 주제 페이지"""
    try:
        topics = await use_case.execute()
        
        return templates.TemplateResponse(
            "today.html",
            {
                "request": request,
                "topics": [
                    {
                        "id": topic.id,
                        "title": topic.title,
                        "description": topic.description,
                        "category": topic.category,
                        "tags": topic.tags,
                        "created_at": topic.created_at.strftime("%Y-%m-%d %H:%M") if topic.created_at else "",
                    }
                    for topic in topics
                ],
                "count": len(topics),
            }
        )
    except Exception as e:
        logger.error(f"오늘의 주제 페이지 렌더링 오류: {e}", exc_info=True)
        return templates.TemplateResponse(
            "today.html",
            {
                "request": request,
                "topics": [],
                "count": 0,
            }
        )
