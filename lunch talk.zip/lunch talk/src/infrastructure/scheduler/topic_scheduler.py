from datetime import datetime
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from ...application.use_cases.generate_topics import GenerateTopicsUseCase
from ...infrastructure.database.session import get_db_session
from ...infrastructure.repositories.topic_repository_impl import TopicRepositoryImpl
from ...infrastructure.ai_agent.openai_topic_generator import OpenAITopicGenerator


class TopicScheduler:
    """주제 생성 스케줄러"""
    
    def __init__(self):
        self._scheduler = AsyncIOScheduler()
        try:
            self._topic_generator = OpenAITopicGenerator()
        except ValueError as e:
            print(f"[경고] 스케줄러 초기화 실패: {e}. OPENAI_API_KEY를 확인하세요.")
            self._topic_generator = None
    
    async def _generate_daily_topics(self):
        """매일 오전 9시 주제 생성 작업"""
        if self._topic_generator is None:
            print("[스케줄러] 주제 생성기가 설정되지 않아 작업을 건너뜁니다.")
            return
        
        async for session in get_db_session():
            try:
                topic_repository = TopicRepositoryImpl(session)
                use_case = GenerateTopicsUseCase(
                    topic_generator=self._topic_generator,
                    topic_repository=topic_repository,
                )
                
                topics = await use_case.execute(count=5)
                print(f"[스케줄러] {len(topics)}개의 주제가 생성되었습니다.")
            except Exception as e:
                print(f"[스케줄러] 주제 생성 중 오류 발생: {e}")
            finally:
                break
    
    def start(self):
        """스케줄러 시작"""
        # 매일 오전 9시에 실행
        self._scheduler.add_job(
            self._generate_daily_topics,
            trigger=CronTrigger(hour=9, minute=0),
            id="generate_daily_topics",
            name="매일 오전 9시 주제 생성",
        )
        self._scheduler.start()
        print("[스케줄러] 주제 생성 스케줄러가 시작되었습니다. (매일 오전 9시)")
    
    def shutdown(self):
        """스케줄러 종료"""
        self._scheduler.shutdown()

