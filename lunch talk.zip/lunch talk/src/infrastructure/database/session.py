from sqlalchemy import create_engine
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from pydantic_settings import BaseSettings


class DatabaseSettings(BaseSettings):
    """데이터베이스 설정"""
    database_url: str = "sqlite:///./lunch_talk.db"
    
    class Config:
        env_file = ".env"
        env_prefix = "DATABASE_"


def get_database_url() -> str:
    """데이터베이스 URL 가져오기"""
    settings = DatabaseSettings()
    url = settings.database_url
    
    # SQLite의 경우 async URL로 변환
    if url.startswith("sqlite:///"):
        url = url.replace("sqlite:///", "sqlite+aiosqlite:///")
    elif url.startswith("sqlite://"):
        url = url.replace("sqlite://", "sqlite+aiosqlite://")
    
    return url


def create_async_session_factory():
    """비동기 세션 팩토리 생성"""
    engine = create_async_engine(
        get_database_url(),
        echo=False,
        future=True,
    )
    return sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )


_session_factory = None


def get_session_factory():
    """세션 팩토리 싱글톤"""
    global _session_factory
    if _session_factory is None:
        _session_factory = create_async_session_factory()
    return _session_factory


async def get_db_session() -> AsyncSession:
    """데이터베이스 세션 생성"""
    session_factory = get_session_factory()
    async with session_factory() as session:
        yield session

