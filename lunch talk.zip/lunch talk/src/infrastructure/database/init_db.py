"""데이터베이스 초기화 스크립트"""
from sqlalchemy.ext.asyncio import create_async_engine
from .models import Base
from .session import get_database_url


async def init_db():
    """데이터베이스 테이블 생성"""
    engine = create_async_engine(get_database_url(), echo=True)
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    await engine.dispose()
    print("데이터베이스 초기화가 완료되었습니다.")


if __name__ == "__main__":
    import asyncio
    asyncio.run(init_db())

