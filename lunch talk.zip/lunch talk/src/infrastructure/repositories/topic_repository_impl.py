from datetime import datetime
from typing import Optional, List
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ...domain.entities.topic import Topic
from ...domain.repositories.topic_repository import TopicRepository
from ..database.models import TopicModel


class TopicRepositoryImpl(TopicRepository):
    """주제 저장소 구현"""
    
    def __init__(self, session: AsyncSession):
        self._session = session
    
    def _to_entity(self, model: TopicModel) -> Topic:
        """모델을 엔티티로 변환"""
        return Topic(
            id=model.id,
            title=model.title,
            description=model.description,
            category=model.category,
            tags=model.tags or [],
            created_at=model.created_at,
            is_active=model.is_active,
        )
    
    def _to_model(self, entity: Topic) -> TopicModel:
        """엔티티를 모델로 변환"""
        return TopicModel(
            id=entity.id,
            title=entity.title,
            description=entity.description,
            category=entity.category,
            tags=entity.tags,
            created_at=entity.created_at,
            is_active=entity.is_active,
        )
    
    async def create(self, topic: Topic) -> Topic:
        """주제 생성"""
        model = self._to_model(topic)
        self._session.add(model)
        await self._session.commit()
        await self._session.refresh(model)
        return self._to_entity(model)
    
    async def get_by_id(self, topic_id: int) -> Optional[Topic]:
        """ID로 주제 조회"""
        result = await self._session.execute(
            select(TopicModel).where(TopicModel.id == topic_id)
        )
        model = result.scalar_one_or_none()
        return self._to_entity(model) if model else None
    
    async def get_active_topics(self, limit: Optional[int] = None) -> List[Topic]:
        """활성화된 주제 목록 조회"""
        query = select(TopicModel).where(
            TopicModel.is_active == True
        ).order_by(TopicModel.created_at.desc())
        
        if limit:
            query = query.limit(limit)
        
        result = await self._session.execute(query)
        models = result.scalars().all()
        return [self._to_entity(model) for model in models]
    
    async def get_topics_by_date(self, date: datetime) -> List[Topic]:
        """특정 날짜의 주제 목록 조회"""
        next_day = date.replace(hour=23, minute=59, second=59)
        result = await self._session.execute(
            select(TopicModel).where(
                TopicModel.created_at >= date,
                TopicModel.created_at <= next_day,
            ).order_by(TopicModel.created_at.desc())
        )
        models = result.scalars().all()
        return [self._to_entity(model) for model in models]
    
    async def update(self, topic: Topic) -> Topic:
        """주제 업데이트"""
        result = await self._session.execute(
            select(TopicModel).where(TopicModel.id == topic.id)
        )
        model = result.scalar_one()
        
        model.title = topic.title
        model.description = topic.description
        model.category = topic.category
        model.tags = topic.tags
        model.is_active = topic.is_active
        
        await self._session.commit()
        await self._session.refresh(model)
        return self._to_entity(model)
    
    async def deactivate_old_topics(self, before_date: datetime) -> int:
        """특정 날짜 이전의 주제들을 비활성화"""
        result = await self._session.execute(
            select(TopicModel).where(
                TopicModel.created_at < before_date,
                TopicModel.is_active == True,
            )
        )
        models = result.scalars().all()
        
        count = 0
        for model in models:
            model.is_active = False
            count += 1
        
        await self._session.commit()
        return count

