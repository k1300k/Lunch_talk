import json
from datetime import datetime
from typing import List
from openai import AsyncOpenAI
from pydantic_settings import BaseSettings

from ...domain.entities.topic import Topic
from ...domain.services.topic_generator import TopicGenerator


class AISettings(BaseSettings):
    """AI 설정"""
    openai_api_key: str = ""
    
    class Config:
        env_file = ".env"
        env_prefix = "OPENAI_"


class OpenAITopicGenerator(TopicGenerator):
    """OpenAI 기반 주제 생성기"""
    
    def __init__(self):
        settings = AISettings()
        if not settings.openai_api_key:
            raise ValueError("OPENAI_API_KEY가 설정되지 않았습니다")
        
        self._client = AsyncOpenAI(api_key=settings.openai_api_key)
    
    async def generate_topics(self, count: int = 5) -> List[Topic]:
        """스몰톡 주제 생성"""
        prompt = self._create_prompt(count)
        
        response = await self._client.chat.completions.create(
            model="gpt-4",
            messages=[
                {
                    "role": "system",
                    "content": "당신은 20~40대 직장인들을 위한 스몰톡 주제를 생성하는 전문가입니다. 정치, 종교 등 민감한 주제는 피하고, 자연스럽고 부담 없는 대화 주제를 만듭니다."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            response_format={"type": "json_object"},
            temperature=0.8,
        )
        
        content = response.choices[0].message.content
        data = json.loads(content)
        
        topics = []
        for item in data.get("topics", []):
            topic = Topic(
                id=None,
                title=item["title"],
                description=item["description"],
                category=item.get("category", "일반"),
                tags=item.get("tags", []),
                created_at=datetime.now(),
                is_active=True,
            )
            topics.append(topic)
        
        return topics
    
    def _create_prompt(self, count: int) -> str:
        """프롬프트 생성"""
        return f"""다음 조건을 만족하는 스몰톡 주제 {count}개를 생성해주세요:

조건:
1. 20~40대 직장인에게 적합한 주제
2. 정치, 종교 등 민감한 주제 제외
3. 자연스럽고 부담 없는 대화 주제
4. 최근 트렌드나 일상적인 주제 포함

각 주제는 다음 형식으로 JSON으로 제공해주세요:
{{
  "topics": [
    {{
      "title": "주제 제목 (예: 최근 본 드라마 추천)",
      "description": "주제에 대한 간단한 설명 (예: 요즘 인기 있는 드라마나 시리즈를 공유하고 추천하는 대화)",
      "category": "카테고리 (예: 엔터테인먼트, 음식, 취미, 여행 등)",
      "tags": ["태그1", "태그2"]
    }}
  ]
}}

JSON 형식으로만 응답해주세요."""

