from datetime import datetime
from typing import List
from ...domain.entities.topic import Topic
from ...domain.repositories.topic_repository import TopicRepository


class GetTodayTopicsUseCase:
    """오늘의 주제 조회 Use Case"""
    
    def __init__(self, topic_repository: TopicRepository):
        self._topic_repository = topic_repository
    
    async def execute(self) -> List[Topic]:
        """
        오늘 생성된 주제 목록 조회
        
        Returns:
            오늘의 주제 리스트
        """
        today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        return await self._topic_repository.get_topics_by_date(today)

