from datetime import datetime
from typing import List
from ...domain.entities.topic import Topic
from ...domain.repositories.topic_repository import TopicRepository
from ...domain.services.topic_generator import TopicGenerator


class GenerateTopicsUseCase:
    """주제 생성 Use Case"""
    
    def __init__(
        self,
        topic_generator: TopicGenerator,
        topic_repository: TopicRepository,
    ):
        self._topic_generator = topic_generator
        self._topic_repository = topic_repository
    
    async def execute(self, count: int = 5) -> List[Topic]:
        """
        주제를 생성하고 저장
        
        Args:
            count: 생성할 주제 개수
            
        Returns:
            생성된 주제 리스트
        """
        # AI로 주제 생성
        topics = await self._topic_generator.generate_topics(count=count)
        
        # 안전한 주제만 필터링
        safe_topics = [topic for topic in topics if topic.is_safe()]
        
        # 주제 저장
        saved_topics = []
        for topic in safe_topics:
            saved_topic = await self._topic_repository.create(topic)
            saved_topics.append(saved_topic)
        
        return saved_topics

