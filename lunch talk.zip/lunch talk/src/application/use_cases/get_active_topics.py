from typing import List, Optional
from ...domain.entities.topic import Topic
from ...domain.repositories.topic_repository import TopicRepository


class GetActiveTopicsUseCase:
    """활성화된 주제 조회 Use Case"""
    
    def __init__(self, topic_repository: TopicRepository):
        self._topic_repository = topic_repository
    
    async def execute(self, limit: Optional[int] = None) -> List[Topic]:
        """
        활성화된 주제 목록 조회
        
        Args:
            limit: 조회할 최대 개수
            
        Returns:
            활성화된 주제 리스트
        """
        return await self._topic_repository.get_active_topics(limit=limit)

