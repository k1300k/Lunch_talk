"""로깅 설정"""
import logging
import sys
from pathlib import Path
from pydantic_settings import BaseSettings


class LogSettings(BaseSettings):
    """로깅 설정"""
    log_level: str = "INFO"
    
    class Config:
        env_file = ".env"
        env_prefix = "LOG_"


def setup_logging():
    """로깅 설정 초기화"""
    settings = LogSettings()
    
    # 로그 레벨 설정
    log_level = getattr(logging, settings.log_level.upper(), logging.INFO)
    
    # 로깅 포맷 설정
    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"
    
    # 기본 로깅 설정
    logging.basicConfig(
        level=log_level,
        format=log_format,
        datefmt=date_format,
        handlers=[
            logging.StreamHandler(sys.stdout),
        ],
    )
    
    # SQLAlchemy 로깅 레벨 조정
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)
    
    return logging.getLogger(__name__)

