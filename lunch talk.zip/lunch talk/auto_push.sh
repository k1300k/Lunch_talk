#!/bin/bash
# GitHub 자동 푸시 스크립트

cd "$(dirname "$0")"

echo "=========================================="
echo "🚀 GitHub에 푸시하기"
echo "=========================================="
echo ""

# 1. 저장소 생성 확인
echo "[1/3] GitHub 저장소 확인"
echo "저장소 URL: https://github.com/k1300k/lunch-talk-recommender"
echo ""
echo "⚠️ 저장소가 없다면 먼저 생성하세요:"
echo "   https://github.com/new"
echo "   Repository name: lunch-talk-recommender"
echo "   (README 초기화 체크하지 않기)"
echo ""
read -p "저장소가 준비되었나요? (y/n): " ready

if [ "$ready" != "y" ]; then
    echo "저장소를 먼저 생성해주세요."
    exit 1
fi

# 2. Personal Access Token 입력
echo ""
echo "[2/3] Personal Access Token 입력"
echo "토큰 생성: https://github.com/settings/tokens"
echo "권한: repo (전체)"
echo ""
read -sp "Personal Access Token 입력: " token
echo ""

if [ -z "$token" ]; then
    echo "❌ 토큰이 입력되지 않았습니다."
    exit 1
fi

# 3. 푸시
echo ""
echo "[3/3] GitHub에 푸시 중..."

# 원격 URL에 토큰 포함
git remote set-url origin "https://${token}@github.com/k1300k/lunch-talk-recommender.git"

# 푸시 실행
if git push -u origin main; then
    echo ""
    echo "✅ 성공적으로 푸시되었습니다!"
    echo "📍 https://github.com/k1300k/lunch-talk-recommender"
    
    # 보안을 위해 URL 변경
    git remote set-url origin "https://github.com/k1300k/lunch-talk-recommender.git"
    echo ""
    echo "✅ 원격 URL이 토큰 없이 설정되었습니다."
else
    echo ""
    echo "❌ 푸시 실패"
    echo "확인 사항:"
    echo "  1. 저장소가 생성되었는지 확인"
    echo "  2. 토큰이 올바른지 확인"
    exit 1
fi

