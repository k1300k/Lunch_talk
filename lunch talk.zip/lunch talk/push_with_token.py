#!/usr/bin/env python3
"""Personal Access Token을 사용하여 GitHub에 푸시하는 스크립트"""
import subprocess
import sys
import getpass

print("=" * 70)
print("🚀 GitHub에 푸시하기")
print("=" * 70)

# 1단계: 저장소 존재 확인
print("\n[1/3] GitHub 저장소 확인 중...")
repo_url = "https://github.com/k1300k/lunch-talk-recommender"
print(f"저장소 URL: {repo_url}")
print("\n⚠️ 저장소가 아직 생성되지 않았다면:")
print("   1. https://github.com/new 접속")
print("   2. Repository name: lunch-talk-recommender")
print("   3. 'Initialize this repository with a README' 체크하지 않기")
print("   4. Create repository 클릭")
print("\n계속하려면 Enter를 누르세요...")
input()

# 2단계: Personal Access Token 입력
print("\n[2/3] Personal Access Token 입력")
print("=" * 70)
print("토큰이 없다면:")
print("   1. https://github.com/settings/tokens 접속")
print("   2. 'Generate new token (classic)' 클릭")
print("   3. 'repo' 권한 선택")
print("   4. 토큰 생성 후 복사")
print("=" * 70)

token = getpass.getpass("Personal Access Token 입력: ")

if not token:
    print("❌ 토큰이 입력되지 않았습니다.")
    sys.exit(1)

# 3단계: Git credential helper 설정 및 푸시
print("\n[3/3] GitHub에 푸시 중...")

# URL에 토큰 포함
push_url = f"https://{token}@github.com/k1300k/lunch-talk-recommender.git"

try:
    # 원격 URL을 토큰 포함 URL로 임시 변경
    subprocess.run(
        ["git", "remote", "set-url", "origin", push_url],
        check=True,
        capture_output=True
    )
    
    # 푸시 실행
    result = subprocess.run(
        ["git", "push", "-u", "origin", "main"],
        capture_output=True,
        text=True
    )
    
    if result.returncode == 0:
        print("\n✅ GitHub에 성공적으로 푸시되었습니다!")
        print(f"\n📍 저장소 URL: {repo_url}")
        print("\n⚠️ 보안을 위해 다음 명령어로 URL을 변경하세요:")
        print("   git remote set-url origin https://github.com/k1300k/lunch-talk-recommender.git")
    else:
        print("\n❌ 푸시 실패:")
        print(result.stderr)
        print("\n오류 해결 방법:")
        print("   1. 저장소가 생성되었는지 확인")
        print("   2. 토큰이 올바른지 확인")
        print("   3. 토큰에 'repo' 권한이 있는지 확인")
        
except subprocess.CalledProcessError as e:
    print(f"\n❌ 오류 발생: {e}")
    sys.exit(1)

