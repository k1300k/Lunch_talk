# 📤 GitHub에 업로드하기 - 다양한 방법

## 방법 1: ZIP 파일 업로드 (가장 간단) ⭐

### 1단계: ZIP 파일 생성

터미널에서:
```bash
cd "/Users/john/lunch talk"
./create_zip.sh
```

또는 수동으로:
```bash
zip -r lunch-talk-recommender.zip . -x "*.git*" -x "*.db" -x "venv/*"
```

### 2단계: GitHub에서 업로드

1. **새 저장소 생성**: https://github.com/new
   - Repository name: `lunch-talk-recommender`
   - Description: `Small Talk Topic Recommender Service`
   - Public 또는 Private 선택
   - **"Initialize this repository with a README" 체크**
   - "Create repository" 클릭

2. **파일 업로드**
   - "uploading an existing file" 클릭
   - `lunch-talk-recommender.zip` 파일 드래그 앤 드롭
   - 또는 "choose your files" 클릭하여 파일 선택
   - "Commit changes" 클릭

3. **ZIP 파일 압축 해제** (GitHub에서는 자동 처리 안됨)
   - 저장소가 생성된 후
   - "Add file" → "Upload files" 클릭
   - ZIP 파일의 내용을 개별적으로 업로드

## 방법 2: GitHub 웹 인터페이스로 직접 업로드

### 1단계: 저장소 생성
- https://github.com/new 접속
- Repository name: `lunch-talk-recommender`
- "Initialize this repository with a README" 체크하지 않기
- Create repository 클릭

### 2단계: 파일 업로드
- "uploading an existing file" 클릭
- 주요 파일들을 드래그 앤 드롭:
  - `src/` 폴더 전체
  - `tests/` 폴더 전체
  - `templates/` 폴더 전체
  - `static/` 폴더 전체
  - `requirements.txt`
  - `README.md`
  - 기타 설정 파일들

### 3단계: 커밋
- "Commit changes" 클릭

## 방법 3: GitHub Desktop 사용

1. GitHub Desktop 설치: https://desktop.github.com/
2. File → Add Local Repository
3. `/Users/john/lunch talk` 선택
4. Publish repository 클릭
5. Repository name: `lunch-talk-recommender`
6. Publish 클릭

## 방법 4: Git 명령어 (토큰 필요)

```bash
cd "/Users/john/lunch talk"

# Personal Access Token 생성: https://github.com/settings/tokens
# 권한: repo (전체)

# 저장소가 이미 생성되어 있다면:
git push -u origin main
```

## 📦 ZIP 파일 생성 완료

`lunch-talk-recommender.zip` 파일이 생성되었습니다.

이 파일을:
1. GitHub 웹 인터페이스에 직접 업로드
2. 또는 압축 해제 후 개별 파일 업로드

## ⚡ 가장 빠른 방법

1. ZIP 파일 생성: `./create_zip.sh`
2. https://github.com/new 접속
3. 저장소 생성
4. "uploading an existing file" 클릭
5. ZIP 파일 드래그 앤 드롭
6. "Commit changes" 클릭

## 🔗 참고

- GitHub 계정: k1300k
- 저장소 URL: https://github.com/k1300k/lunch-talk-recommender

