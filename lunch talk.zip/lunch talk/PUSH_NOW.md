# ⚡ 지금 바로 GitHub에 올리기

## ✅ 준비 완료된 것

- ✅ 모든 파일 커밋 완료
- ✅ 원격 저장소 연결: `https://github.com/k1300k/lunch-talk-recommender.git`
- ✅ 푸시 스크립트 준비

## 🚀 3단계로 올리기

### 1단계: GitHub 저장소 생성 (1분)

https://github.com/new 접속 후:
- Repository name: **lunch-talk-recommender**
- Description: **Small Talk Topic Recommender Service**
- Public 또는 Private 선택
- ⚠️ **"Initialize this repository with a README" 체크하지 않기**
- Create repository 클릭

### 2단계: Personal Access Token 생성 (2분)

https://github.com/settings/tokens 접속 후:
- "Generate new token (classic)" 클릭
- Token name: **lunch-talk-recommender**
- 권한: **repo** (전체 선택)
- "Generate token" 클릭
- **토큰 복사** (한 번만 표시!)

### 3단계: 푸시 실행 (30초)

터미널에서:

```bash
cd "/Users/john/lunch talk"
./auto_push.sh
```

토큰 입력하면 자동으로 푸시됩니다!

---

## 🎯 빠른 명령어

저장소와 토큰이 준비되었다면:

```bash
cd "/Users/john/lunch talk"
read -sp "Personal Access Token: " TOKEN && \
git remote set-url origin "https://${TOKEN}@github.com/k1300k/lunch-talk-recommender.git" && \
git push -u origin main && \
git remote set-url origin "https://github.com/k1300k/lunch-talk-recommender.git" && \
echo "✅ 푸시 완료!"
```

