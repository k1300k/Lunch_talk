#!/bin/bash
# 서버 시작 스크립트

cd "$(dirname "$0")"

echo "🚀 Small Talk Topic Recommender 서버 시작 중..."
echo ""

# 의존성 확인
python3 -c "import fastapi, uvicorn, sqlalchemy, jinja2" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "⚠️ 의존성 패키지가 설치되지 않았습니다."
    echo "설치 중..."
    python3 -m pip install --user -q fastapi uvicorn[standard] sqlalchemy aiosqlite jinja2 aiofiles pydantic pydantic-settings python-dotenv apscheduler 2>&1 | tail -3
fi

# 데이터베이스 초기화
if [ ! -f "lunch_talk.db" ]; then
    echo "📦 데이터베이스 초기화 중..."
    python3 -c "import sys; sys.path.insert(0, '.'); import asyncio; from src.infrastructure.database.init_db import init_db; asyncio.run(init_db())" 2>&1
fi

echo ""
echo "✅ 서버를 시작합니다..."
echo "📍 브라우저에서 http://localhost:8000 으로 접속하세요"
echo "📍 API 문서: http://localhost:8000/docs"
echo ""
echo "서버를 종료하려면 Ctrl+C를 누르세요"
echo ""

# macOS에서 브라우저 자동 열기
if [[ "$OSTYPE" == "darwin"* ]]; then
    sleep 2 && open http://localhost:8000 &
fi

# 서버 실행
python3 src/main.py

