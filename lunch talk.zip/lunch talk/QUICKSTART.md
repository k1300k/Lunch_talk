# 🚀 빠른 시작 가이드

## 서버 실행 방법

### 방법 1: run_server.py 사용 (권장)

```bash
python3 run_server.py
```

이 스크립트가 의존성 확인 및 데이터베이스 초기화를 자동으로 수행합니다.

### 방법 2: 수동 실행

```bash
# 1. 의존성 설치
pip3 install -r requirements.txt

# 2. 데이터베이스 초기화
python3 -m src.infrastructure.database.init_db

# 3. 서버 실행
python3 src/main.py
```

## 웹 화면 접속

서버가 실행되면 브라우저에서 다음 주소로 접속하세요:

- **메인 페이지**: http://localhost:8000/
- **오늘의 주제**: http://localhost:8000/today
- **API 문서**: http://localhost:8000/docs

## 문제 해결

### 의존성 설치 오류 시

```bash
# 최소 필수 패키지만 설치
pip3 install fastapi uvicorn sqlalchemy aiosqlite jinja2 aiofiles pydantic pydantic-settings python-dotenv
```

### 데이터베이스 오류 시

```bash
# 데이터베이스 파일 삭제 후 재생성
rm lunch_talk.db
python3 -m src.infrastructure.database.init_db
```

### 포트가 이미 사용 중일 때

다른 포트로 실행:

```bash
uvicorn src.presentation.api.main:app --port 8001
```

