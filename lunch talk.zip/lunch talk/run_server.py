#!/usr/bin/env python3
"""서버 실행 스크립트"""
import sys
import subprocess
from pathlib import Path

def check_dependencies():
    """의존성 확인"""
    try:
        import fastapi
        import uvicorn
        import sqlalchemy
        import jinja2
        return True
    except ImportError as e:
        print(f"❌ 의존성이 설치되지 않았습니다: {e}")
        print("\n다음 명령어로 의존성을 설치하세요:")
        print("  pip3 install -r requirements.txt")
        print("  또는")
        print("  python3 -m pip install fastapi uvicorn sqlalchemy aiosqlite jinja2 aiofiles")
        return False

def init_database():
    """데이터베이스 초기화"""
    try:
        import asyncio
        from src.infrastructure.database.init_db import init_db
        asyncio.run(init_db())
        print("✅ 데이터베이스 초기화 완료")
        return True
    except Exception as e:
        print(f"⚠️ 데이터베이스 초기화 오류: {e}")
        print("데이터베이스 없이 진행합니다...")
        return False

def run_server():
    """서버 실행"""
    import uvicorn
    print("\n🚀 서버를 시작합니다...")
    print("📍 브라우저에서 http://localhost:8000 으로 접속하세요")
    print("📍 API 문서: http://localhost:8000/docs")
    print("\n서버를 종료하려면 Ctrl+C를 누르세요\n")
    
    uvicorn.run(
        "src.presentation.api.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
    )

if __name__ == "__main__":
    if not check_dependencies():
        sys.exit(1)
    
    # 데이터베이스 초기화 시도
    init_database()
    
    # 서버 실행
    run_server()

