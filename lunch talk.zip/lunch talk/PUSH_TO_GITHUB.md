# 📤 GitHub에 푸시하기

## 저장소 정보

- **GitHub 계정**: k1300k
- **저장소 이름**: lunch-talk-recommender
- **저장소 URL**: https://github.com/k1300k/lunch-talk-recommender

## 1단계: GitHub에서 저장소 생성

아직 저장소가 생성되지 않았다면:

1. https://github.com/new 접속
2. Repository name: `lunch-talk-recommender`
3. Description: "Small Talk Topic Recommender Service - AI 기반 스몰톡 주제 추천 서비스"
4. Public 또는 Private 선택
5. **중요**: "Initialize this repository with a README" 체크하지 않기
6. "Create repository" 클릭

## 2단계: 푸시

저장소가 생성되었다면, 터미널에서 다음 명령어 실행:

```bash
cd "/Users/john/lunch talk"
git push -u origin main
```

## 인증

푸시 시 GitHub 인증이 필요합니다:

### Personal Access Token 사용 (권장)

1. GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
2. "Generate new token (classic)" 클릭
3. Token name: `lunch-talk-recommender`
4. 권한 선택: `repo` (전체 선택)
5. "Generate token" 클릭
6. 토큰 복사 (한 번만 표시됨!)
7. 푸시 시 비밀번호 대신 토큰 사용

## 3단계: 확인

푸시 완료 후 다음 URL에서 확인:
https://github.com/k1300k/lunch-talk-recommender

