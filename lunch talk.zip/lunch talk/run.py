#!/usr/bin/env python3
"""서버 실행 스크립트 - PYTHONPATH 설정 포함"""
import sys
import os
from pathlib import Path

# 프로젝트 루트를 PYTHONPATH에 추가
PROJECT_ROOT = Path(__file__).parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT))

# 환경 변수 설정
os.environ['PYTHONPATH'] = str(PROJECT_ROOT)

print("=" * 70)
print("🚀 Small Talk Topic Recommender 서버 시작")
print("=" * 70)

# 의존성 빠른 확인
try:
    import fastapi
    import uvicorn
    import sqlalchemy
except ImportError as e:
    print(f"❌ 의존성이 설치되지 않았습니다: {e}")
    print("다음 명령어로 설치하세요:")
    print("  pip3 install --user fastapi uvicorn sqlalchemy aiosqlite jinja2 aiofiles")
    sys.exit(1)

# 데이터베이스 확인
db_file = PROJECT_ROOT / "lunch_talk.db"
if not db_file.exists():
    print("\n📦 데이터베이스 초기화 중...")
    try:
        import asyncio
        from src.infrastructure.database.init_db import init_db
        asyncio.run(init_db())
        print("✅ 데이터베이스 초기화 완료")
    except Exception as e:
        print(f"⚠️ 데이터베이스 초기화 오류: {e}")

print("\n📍 브라우저에서 다음 주소로 접속하세요:")
print("   메인 페이지: http://localhost:8000/")
print("   오늘의 주제: http://localhost:8000/today")
print("   API 문서: http://localhost:8000/docs")
print("\n서버를 종료하려면 Ctrl+C를 누르세요")
print("=" * 70 + "\n")

# macOS 브라우저 자동 열기
if sys.platform == "darwin":
    import subprocess
    import threading
    import time
    
    def open_browser():
        time.sleep(3)
        try:
            subprocess.Popen(["open", "http://localhost:8000"], 
                           stdout=subprocess.DEVNULL, 
                           stderr=subprocess.DEVNULL)
        except:
            pass
    
    threading.Thread(target=open_browser, daemon=True).start()

# 서버 실행
try:
    import uvicorn
    
    # 모듈 문자열로 실행 (PYTHONPATH가 설정되어 있으므로 정상 작동)
    uvicorn.run(
        "src.presentation.api.main:app",
        host="127.0.0.1",
        port=8000,
        reload=False,
        log_level="info",
    )
except KeyboardInterrupt:
    print("\n\n✅ 서버를 종료합니다...")
except Exception as e:
    print(f"\n❌ 서버 실행 오류: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

