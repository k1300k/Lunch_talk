#!/usr/bin/env python3
"""간단한 서버 실행 스크립트"""
import sys
import os
from pathlib import Path

# 프로젝트 루트를 경로에 추가
project_root = Path(__file__).parent.resolve()
sys.path.insert(0, str(project_root))

def check_and_install_dependencies():
    """의존성 확인 및 안내"""
    missing = []
    try:
        import fastapi
    except ImportError:
        missing.append("fastapi")
    
    try:
        import uvicorn
    except ImportError:
        missing.append("uvicorn")
    
    try:
        import sqlalchemy
    except ImportError:
        missing.append("sqlalchemy")
    
    try:
        import aiosqlite
    except ImportError:
        missing.append("aiosqlite")
    
    try:
        import jinja2
    except ImportError:
        missing.append("jinja2")
    
    if missing:
        print("❌ 다음 패키지가 설치되지 않았습니다:")
        print(f"   {', '.join(missing)}")
        print("\n다음 명령어로 설치하세요:")
        print(f"   pip3 install --user {' '.join(missing)}")
        return False
    
    return True

def init_database():
    """데이터베이스 초기화"""
    try:
        import asyncio
        from src.infrastructure.database.init_db import init_db
        
        db_file = project_root / "lunch_talk.db"
        if not db_file.exists():
            print("📦 데이터베이스 초기화 중...")
            asyncio.run(init_db())
            print("✅ 데이터베이스 초기화 완료")
        else:
            print("✅ 데이터베이스 파일이 이미 존재합니다")
        return True
    except Exception as e:
        print(f"⚠️ 데이터베이스 초기화 오류 (계속 진행): {e}")
        return True  # 계속 진행

def run_server():
    """서버 실행"""
    try:
        import uvicorn
        
        print("\n" + "="*50)
        print("🚀 Small Talk Topic Recommender 서버 시작")
        print("="*50)
        print("\n📍 브라우저에서 다음 주소로 접속하세요:")
        print("   - 메인 페이지: http://localhost:8000/")
        print("   - 오늘의 주제: http://localhost:8000/today")
        print("   - API 문서: http://localhost:8000/docs")
        print("\n서버를 종료하려면 Ctrl+C를 누르세요")
        print("="*50 + "\n")
        
        # macOS에서 브라우저 자동 열기
        import subprocess
        import time
        import threading
        
        def open_browser():
            time.sleep(2)
            if sys.platform == "darwin":
                subprocess.Popen(["open", "http://localhost:8000"])
        
        threading.Thread(target=open_browser, daemon=True).start()
        
        uvicorn.run(
            "src.presentation.api.main:app",
            host="127.0.0.1",
            port=8000,
            reload=False,
            log_level="info",
        )
    except KeyboardInterrupt:
        print("\n\n서버를 종료합니다...")
    except Exception as e:
        print(f"\n❌ 서버 실행 오류: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    print("🔍 의존성 확인 중...")
    if not check_and_install_dependencies():
        sys.exit(1)
    
    print("✅ 모든 의존성이 설치되어 있습니다")
    
    init_database()
    run_server()

