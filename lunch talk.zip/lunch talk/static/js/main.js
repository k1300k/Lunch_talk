// 메인 JavaScript 파일

// 페이지 로드 시 애니메이션
document.addEventListener('DOMContentLoaded', function() {
    // 카드 애니메이션
    const cards = document.querySelectorAll('.topic-card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.5s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
});

// 카드 클릭 시 상세 정보 표시 (향후 확장 가능)
document.addEventListener('click', function(e) {
    const card = e.target.closest('.topic-card');
    if (card) {
        // 카드 클릭 시 추가 기능 구현 가능
        console.log('Card clicked:', card.dataset.id);
    }
});

