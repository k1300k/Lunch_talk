#!/bin/bash
# GitHub에 업로드할 ZIP 파일 생성

cd "$(dirname "$0")"

echo "📦 GitHub 업로드용 ZIP 파일 생성 중..."

# Git 관련 파일 제외하고 ZIP 생성
zip -r lunch-talk-recommender.zip . \
  -x "*.git*" \
  -x "*.pyc" \
  -x "__pycache__/*" \
  -x "*.db" \
  -x "*.sqlite" \
  -x "venv/*" \
  -x "env/*" \
  -x ".pytest_cache/*" \
  -x "htmlcov/*" \
  -x ".DS_Store" \
  -x "*.log"

if [ $? -eq 0 ]; then
  echo "✅ ZIP 파일 생성 완료: lunch-talk-recommender.zip"
  echo ""
  echo "📤 GitHub에 업로드하는 방법:"
  echo "   1. https://github.com/new 접속"
  echo "   2. Repository name: lunch-talk-recommender"
  echo "   3. 'Initialize this repository with a README' 체크"
  echo "   4. Create repository 클릭"
  echo "   5. 'uploading an existing file' 클릭"
  echo "   6. lunch-talk-recommender.zip 파일 드래그 앤 드롭"
  echo "   7. 'Commit changes' 클릭"
else
  echo "❌ ZIP 파일 생성 실패"
  exit 1
fi

