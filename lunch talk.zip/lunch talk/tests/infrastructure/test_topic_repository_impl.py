"""주제 저장소 구현 테스트"""
import pytest
from datetime import datetime, timedelta

from src.domain.entities.topic import Topic
from src.infrastructure.repositories.topic_repository_impl import TopicRepositoryImpl
from src.infrastructure.database.models import TopicModel


@pytest.mark.asyncio
async def test_create_topic(db_session):
    """주제 생성 테스트"""
    # Given
    repository = TopicRepositoryImpl(db_session)
    topic = Topic(
        id=None,
        title="테스트 주제",
        description="테스트 설명",
        category="테스트",
        tags=["태그1", "태그2"],
        created_at=datetime.now(),
        is_active=True,
    )
    
    # When
    result = await repository.create(topic)
    
    # Then
    assert result.id is not None
    assert result.title == "테스트 주제"
    assert result.tags == ["태그1", "태그2"]


@pytest.mark.asyncio
async def test_get_by_id(db_session):
    """ID로 주제 조회 테스트"""
    # Given
    repository = TopicRepositoryImpl(db_session)
    topic = Topic(
        id=None,
        title="테스트 주제",
        description="테스트 설명",
        category="테스트",
        tags=[],
        created_at=datetime.now(),
        is_active=True,
    )
    created_topic = await repository.create(topic)
    
    # When
    result = await repository.get_by_id(created_topic.id)
    
    # Then
    assert result is not None
    assert result.id == created_topic.id
    assert result.title == "테스트 주제"


@pytest.mark.asyncio
async def test_get_active_topics(db_session):
    """활성 주제 목록 조회 테스트"""
    # Given
    repository = TopicRepositoryImpl(db_session)
    
    active_topic = Topic(
        id=None,
        title="활성 주제",
        description="설명",
        category="카테고리",
        tags=[],
        created_at=datetime.now(),
        is_active=True,
    )
    
    inactive_topic = Topic(
        id=None,
        title="비활성 주제",
        description="설명",
        category="카테고리",
        tags=[],
        created_at=datetime.now(),
        is_active=False,
    )
    
    await repository.create(active_topic)
    await repository.create(inactive_topic)
    
    # When
    result = await repository.get_active_topics()
    
    # Then
    assert len(result) == 1
    assert result[0].title == "활성 주제"
    assert result[0].is_active is True


@pytest.mark.asyncio
async def test_get_topics_by_date(db_session):
    """날짜별 주제 조회 테스트"""
    # Given
    repository = TopicRepositoryImpl(db_session)
    
    today = datetime.now().replace(hour=10, minute=0, second=0, microsecond=0)
    yesterday = today - timedelta(days=1)
    
    today_topic = Topic(
        id=None,
        title="오늘 주제",
        description="설명",
        category="카테고리",
        tags=[],
        created_at=today,
        is_active=True,
    )
    
    yesterday_topic = Topic(
        id=None,
        title="어제 주제",
        description="설명",
        category="카테고리",
        tags=[],
        created_at=yesterday,
        is_active=True,
    )
    
    await repository.create(today_topic)
    await repository.create(yesterday_topic)
    
    # When
    today_start = today.replace(hour=0, minute=0, second=0, microsecond=0)
    result = await repository.get_topics_by_date(today_start)
    
    # Then
    assert len(result) == 1
    assert result[0].title == "오늘 주제"

