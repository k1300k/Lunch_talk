"""테스트 공통 설정"""
import pytest
from datetime import datetime
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

from src.domain.entities.topic import Topic
from src.infrastructure.database.models import Base


@pytest.fixture
def sample_topic():
    """샘플 주제 생성"""
    return Topic(
        id=1,
        title="최근 본 드라마 추천",
        description="요즘 인기 있는 드라마나 시리즈를 공유하고 추천하는 대화",
        category="엔터테인먼트",
        tags=["드라마", "추천"],
        created_at=datetime.now(),
        is_active=True,
    )


@pytest.fixture
def sample_unsafe_topic():
    """민감한 주제 샘플"""
    return Topic(
        id=2,
        title="정치인 선거 공약",
        description="정치인들의 선거 공약에 대해 이야기하기",
        category="정치",
        tags=["정치", "선거"],
        created_at=datetime.now(),
        is_active=True,
    )


@pytest.fixture
async def db_session():
    """테스트용 데이터베이스 세션"""
    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        echo=False,
    )
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    async_session_maker = sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )
    
    async with async_session_maker() as session:
        yield session
    
    await engine.dispose()

