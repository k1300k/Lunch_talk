"""활성 주제 조회 Use Case 테스트"""
import pytest
from unittest.mock import AsyncMock
from datetime import datetime

from src.domain.entities.topic import Topic
from src.application.use_cases.get_active_topics import GetActiveTopicsUseCase


@pytest.fixture
def mock_topic_repository():
    """Mock 주제 저장소"""
    repository = AsyncMock()
    return repository


@pytest.fixture
def get_active_topics_use_case(mock_topic_repository):
    """활성 주제 조회 Use Case"""
    return GetActiveTopicsUseCase(topic_repository=mock_topic_repository)


@pytest.mark.asyncio
async def test_get_active_topics_success(get_active_topics_use_case, mock_topic_repository):
    """활성 주제 조회 성공 테스트"""
    # Given
    topics = [
        Topic(
            id=1,
            title="주제 1",
            description="설명 1",
            category="카테고리",
            tags=[],
            created_at=datetime.now(),
            is_active=True,
        ),
        Topic(
            id=2,
            title="주제 2",
            description="설명 2",
            category="카테고리",
            tags=[],
            created_at=datetime.now(),
            is_active=True,
        ),
    ]
    mock_topic_repository.get_active_topics.return_value = topics
    
    # When
    result = await get_active_topics_use_case.execute(limit=None)
    
    # Then
    assert len(result) == 2
    assert result[0].title == "주제 1"
    mock_topic_repository.get_active_topics.assert_called_once_with(limit=None)


@pytest.mark.asyncio
async def test_get_active_topics_with_limit(get_active_topics_use_case, mock_topic_repository):
    """제한된 개수로 활성 주제 조회 테스트"""
    # Given
    topics = [
        Topic(
            id=1,
            title="주제 1",
            description="설명 1",
            category="카테고리",
            tags=[],
            created_at=datetime.now(),
            is_active=True,
        ),
    ]
    mock_topic_repository.get_active_topics.return_value = topics
    
    # When
    result = await get_active_topics_use_case.execute(limit=1)
    
    # Then
    assert len(result) == 1
    mock_topic_repository.get_active_topics.assert_called_once_with(limit=1)

