"""주제 생성 Use Case 테스트"""
import pytest
from unittest.mock import AsyncMock, Mock
from datetime import datetime

from src.domain.entities.topic import Topic
from src.application.use_cases.generate_topics import GenerateTopicsUseCase


@pytest.fixture
def mock_topic_generator():
    """Mock 주제 생성기"""
    generator = AsyncMock()
    return generator


@pytest.fixture
def mock_topic_repository():
    """Mock 주제 저장소"""
    repository = AsyncMock()
    return repository


@pytest.fixture
def generate_topics_use_case(mock_topic_generator, mock_topic_repository):
    """주제 생성 Use Case"""
    return GenerateTopicsUseCase(
        topic_generator=mock_topic_generator,
        topic_repository=mock_topic_repository,
    )


@pytest.mark.asyncio
async def test_generate_topics_success(generate_topics_use_case, mock_topic_generator, mock_topic_repository):
    """주제 생성 성공 테스트"""
    # Given
    safe_topic = Topic(
        id=None,
        title="안전한 주제",
        description="설명",
        category="카테고리",
        tags=[],
        created_at=datetime.now(),
        is_active=True,
    )
    
    unsafe_topic = Topic(
        id=None,
        title="정치 주제",
        description="정치 관련 설명",
        category="정치",
        tags=[],
        created_at=datetime.now(),
        is_active=True,
    )
    
    mock_topic_generator.generate_topics.return_value = [safe_topic, unsafe_topic]
    mock_topic_repository.create.return_value = safe_topic
    
    # When
    result = await generate_topics_use_case.execute(count=2)
    
    # Then
    assert len(result) == 1  # 안전한 주제만 저장됨
    assert result[0].title == "안전한 주제"
    mock_topic_generator.generate_topics.assert_called_once_with(count=2)
    mock_topic_repository.create.assert_called_once()


@pytest.mark.asyncio
async def test_generate_topics_no_safe_topics(generate_topics_use_case, mock_topic_generator, mock_topic_repository):
    """모든 주제가 민감한 경우 테스트"""
    # Given
    unsafe_topic = Topic(
        id=None,
        title="정치 주제",
        description="정치 관련 설명",
        category="정치",
        tags=[],
        created_at=datetime.now(),
        is_active=True,
    )
    
    mock_topic_generator.generate_topics.return_value = [unsafe_topic]
    
    # When
    result = await generate_topics_use_case.execute(count=1)
    
    # Then
    assert len(result) == 0
    mock_topic_repository.create.assert_not_called()

