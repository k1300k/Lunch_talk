"""오늘의 주제 조회 Use Case 테스트"""
import pytest
from unittest.mock import AsyncMock
from datetime import datetime

from src.domain.entities.topic import Topic
from src.application.use_cases.get_today_topics import GetTodayTopicsUseCase


@pytest.fixture
def mock_topic_repository():
    """Mock 주제 저장소"""
    repository = AsyncMock()
    return repository


@pytest.fixture
def get_today_topics_use_case(mock_topic_repository):
    """오늘의 주제 조회 Use Case"""
    return GetTodayTopicsUseCase(topic_repository=mock_topic_repository)


@pytest.mark.asyncio
async def test_get_today_topics_success(get_today_topics_use_case, mock_topic_repository):
    """오늘의 주제 조회 성공 테스트"""
    # Given
    today = datetime.now().replace(hour=10, minute=0, second=0, microsecond=0)
    topics = [
        Topic(
            id=1,
            title="오늘의 주제 1",
            description="설명 1",
            category="카테고리",
            tags=[],
            created_at=today,
            is_active=True,
        ),
    ]
    mock_topic_repository.get_topics_by_date.return_value = topics
    
    # When
    result = await get_today_topics_use_case.execute()
    
    # Then
    assert len(result) == 1
    assert result[0].title == "오늘의 주제 1"
    mock_topic_repository.get_topics_by_date.assert_called_once()


@pytest.mark.asyncio
async def test_get_today_topics_empty(get_today_topics_use_case, mock_topic_repository):
    """오늘 주제가 없는 경우 테스트"""
    # Given
    mock_topic_repository.get_topics_by_date.return_value = []
    
    # When
    result = await get_today_topics_use_case.execute()
    
    # Then
    assert len(result) == 0

