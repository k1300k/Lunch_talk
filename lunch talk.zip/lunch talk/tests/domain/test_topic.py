"""Topic 엔티티 테스트"""
import pytest
from datetime import datetime

from src.domain.entities.topic import Topic


def test_topic_creation(sample_topic):
    """주제 생성 테스트"""
    assert sample_topic.title == "최근 본 드라마 추천"
    assert sample_topic.category == "엔터테인먼트"
    assert sample_topic.is_active is True


def test_topic_validation_empty_title():
    """빈 제목 검증 테스트"""
    with pytest.raises(ValueError, match="제목은 필수입니다"):
        Topic(
            id=None,
            title="",
            description="설명",
            category="카테고리",
            tags=[],
            created_at=datetime.now(),
            is_active=True,
        )


def test_topic_validation_empty_description():
    """빈 설명 검증 테스트"""
    with pytest.raises(ValueError, match="설명은 필수입니다"):
        Topic(
            id=None,
            title="제목",
            description="",
            category="카테고리",
            tags=[],
            created_at=datetime.now(),
            is_active=True,
        )


def test_topic_validation_empty_category():
    """빈 카테고리 검증 테스트"""
    with pytest.raises(ValueError, match="카테고리는 필수입니다"):
        Topic(
            id=None,
            title="제목",
            description="설명",
            category="",
            tags=[],
            created_at=datetime.now(),
            is_active=True,
        )


def test_topic_tags_default():
    """태그 기본값 테스트"""
    topic = Topic(
        id=None,
        title="제목",
        description="설명",
        category="카테고리",
        tags=None,
        created_at=datetime.now(),
        is_active=True,
    )
    assert topic.tags == []


def test_topic_deactivate(sample_topic):
    """주제 비활성화 테스트"""
    sample_topic.deactivate()
    assert sample_topic.is_active is False


def test_topic_activate(sample_topic):
    """주제 활성화 테스트"""
    sample_topic.deactivate()
    sample_topic.activate()
    assert sample_topic.is_active is True


def test_topic_is_safe(sample_topic):
    """안전한 주제 확인 테스트"""
    assert sample_topic.is_safe() is True


def test_topic_is_unsafe(sample_unsafe_topic):
    """민감한 주제 확인 테스트"""
    assert sample_unsafe_topic.is_safe() is False

