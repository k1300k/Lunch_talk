# 📦 GitHub에 업로드하는 방법

## 1단계: GitHub 저장소 생성

1. GitHub (https://github.com)에 로그인
2. 우측 상단의 "+" 버튼 클릭 → "New repository" 선택
3. 저장소 이름 입력 (예: `lunch-talk-recommender`)
4. Public 또는 Private 선택
5. "Create repository" 클릭
6. 생성된 저장소의 URL 복사 (예: `https://github.com/사용자명/lunch-talk-recommender.git`)

## 2단계: 로컬 저장소와 연결

터미널에서 다음 명령어 실행:

```bash
cd "/Users/john/lunch talk"

# 원격 저장소 추가
git remote add origin https://github.com/사용자명/저장소명.git

# 현재 브랜치를 main으로 변경 (필요시)
git branch -M main

# GitHub에 푸시
git push -u origin main
```

## 3단계: 인증 (처음인 경우)

GitHub에 푸시할 때 인증이 필요합니다:

- **Personal Access Token 사용** (권장)
  1. GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
  2. "Generate new token" 클릭
  3. 권한 선택: `repo` (전체 선택)
  4. 토큰 생성 후 복사
  5. 푸시 시 비밀번호 대신 토큰 사용

또는

- **SSH 키 사용**
  ```bash
  # SSH 키 생성 (이미 있다면 스킵)
  ssh-keygen -t ed25519 -C "your_email@example.com"
  
  # SSH 키를 GitHub에 등록
  cat ~/.ssh/id_ed25519.pub
  # 이 출력을 GitHub → Settings → SSH and GPG keys에 추가
  ```

## 4단계: 업데이트 푸시

파일을 수정한 후:

```bash
git add .
git commit -m "변경 사항 설명"
git push
```

## ⚠️ 주의사항

- `.env` 파일은 Git에 포함되지 않습니다 (`.gitignore`에 포함됨)
- 데이터베이스 파일(`*.db`)도 Git에 포함되지 않습니다
- GitHub에 업로드하기 전에 민감한 정보가 코드에 포함되지 않았는지 확인하세요

## 📝 README 업데이트

GitHub 저장소의 README.md에 프로젝트 설명이 이미 포함되어 있습니다.

