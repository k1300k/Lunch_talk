"""데이터베이스 초기화 스크립트"""
import asyncio
import sys
from pathlib import Path

# 프로젝트 루트를 경로에 추가
project_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(project_root))

from src.infrastructure.database.init_db import init_db


async def main():
    """메인 함수"""
    try:
        await init_db()
        print("✅ 데이터베이스 초기화가 완료되었습니다.")
    except Exception as e:
        print(f"❌ 데이터베이스 초기화 중 오류 발생: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())

