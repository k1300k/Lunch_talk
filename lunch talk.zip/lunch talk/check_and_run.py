#!/usr/bin/env python3
"""서버 점검 및 실행 스크립트"""
import sys
from pathlib import Path

# 프로젝트 루트 설정
PROJECT_ROOT = Path(__file__).parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT))

print("=" * 70)
print("🔍 Small Talk Topic Recommender - 전체 점검")
print("=" * 70)

# 1단계: 의존성 확인
print("\n[1/6] 의존성 확인...")
required = ["fastapi", "uvicorn", "sqlalchemy", "aiosqlite", "jinja2", "aiofiles"]
missing = []
for module in required:
    try:
        __import__(module)
        print(f"  ✅ {module}")
    except ImportError:
        print(f"  ❌ {module} 없음")
        missing.append(module)

if missing:
    print(f"\n⚠️ 누락된 패키지: {', '.join(missing)}")
    print(f"설치: pip3 install --user {' '.join(missing)}")
    sys.exit(1)

# 2단계: 데이터베이스 확인
print("\n[2/6] 데이터베이스 확인...")
db_file = PROJECT_ROOT / "lunch_talk.db"
if db_file.exists():
    print(f"  ✅ 데이터베이스 파일 존재")
else:
    print(f"  ⚠️ 데이터베이스 없음, 초기화 중...")
    try:
        import asyncio
        from src.infrastructure.database.init_db import init_db
        asyncio.run(init_db())
        print("  ✅ 초기화 완료")
    except Exception as e:
        print(f"  ❌ 초기화 실패: {e}")
        sys.exit(1)

# 3단계: 템플릿 파일 확인
print("\n[3/6] 템플릿 파일 확인...")
templates_dir = PROJECT_ROOT / "templates"
templates = ["base.html", "index.html", "today.html"]
for t in templates:
    if (templates_dir / t).exists():
        print(f"  ✅ {t}")
    else:
        print(f"  ❌ {t} 없음!")
        sys.exit(1)

# 4단계: 경로 계산 확인
print("\n[4/6] 경로 설정 확인...")
try:
    # main.py에서 경로 계산
    main_file = PROJECT_ROOT / "src" / "presentation" / "api" / "main.py"
    if main_file.exists():
        calculated_base = main_file.parent.parent.parent.parent
        print(f"  main.py 경로: {main_file}")
        print(f"  계산된 BASE_DIR: {calculated_base}")
        print(f"  실제 프로젝트 루트: {PROJECT_ROOT}")
        print(f"  경로 일치: {calculated_base == PROJECT_ROOT}")
        
        # 템플릿 경로 확인
        templates_path = calculated_base / "templates"
        static_path = calculated_base / "static"
        print(f"  템플릿 경로: {templates_path} (존재: {templates_path.exists()})")
        print(f"  정적 파일 경로: {static_path} (존재: {static_path.exists()})")
        
        if not templates_path.exists():
            print("  ⚠️ 경로 계산 오류! 수정 필요")
            sys.exit(1)
except Exception as e:
    print(f"  ❌ 경로 확인 실패: {e}")
    sys.exit(1)

# 5단계: 모듈 경로 테스트
print("\n[5/6] 모듈 경로 테스트...")
try:
    # uvicorn은 문자열로 모듈 경로를 받으므로 직접 임포트하지 않음
    app_module_path = "src.presentation.api.main:app"
    
    # 간단한 모듈 존재 확인
    import importlib.util
    main_path = PROJECT_ROOT / "src" / "presentation" / "api" / "main.py"
    if main_path.exists():
        print(f"  ✅ main.py 파일 존재")
        print(f"  ✅ 모듈 경로: {app_module_path}")
        print(f"  ✅ Uvicorn으로 실행 가능")
    else:
        print(f"  ❌ main.py 파일 없음!")
        sys.exit(1)
        
except Exception as e:
    print(f"  ❌ 경로 확인 실패: {e}")
    sys.exit(1)

# 6단계: 서버 실행 준비
print("\n[6/6] 서버 실행 준비 완료!")
print("=" * 70)
print("✅ 모든 점검이 완료되었습니다!")
print("=" * 70)
print("\n🚀 서버를 시작합니다...")
print("\n📍 브라우저에서 다음 주소로 접속하세요:")
print("   메인 페이지: http://localhost:8000/")
print("   오늘의 주제: http://localhost:8000/today")
print("   API 문서: http://localhost:8000/docs")
print("\n서버를 종료하려면 Ctrl+C를 누르세요")
print("=" * 70 + "\n")

# macOS 브라우저 자동 열기
if sys.platform == "darwin":
    import subprocess
    import threading
    import time
    
    def open_browser():
        time.sleep(3)
        try:
            subprocess.Popen(["open", "http://localhost:8000"], 
                           stdout=subprocess.DEVNULL, 
                           stderr=subprocess.DEVNULL)
            print("🌐 브라우저가 자동으로 열립니다...\n")
        except:
            pass
    
    threading.Thread(target=open_browser, daemon=True).start()

# 서버 실행
try:
    import uvicorn
    # 문자열로 모듈 경로 전달 (상대 임포트 문제 회피)
    uvicorn.run(
        "src.presentation.api.main:app",
        host="127.0.0.1",
        port=8000,
        reload=False,
        log_level="info",
    )
except KeyboardInterrupt:
    print("\n\n✅ 서버를 종료합니다...")
except Exception as e:
    print(f"\n❌ 서버 실행 오류: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

