# 🏗️ 아키텍처 문서

## Clean Architecture 구조

이 프로젝트는 Clean Architecture 원칙을 따라 구성되어 있습니다.

```
src/
├── domain/           # 도메인 레이어 (비즈니스 로직의 핵심)
├── application/      # 애플리케이션 레이어 (Use Cases)
├── infrastructure/   # 인프라 레이어 (외부 의존성)
└── presentation/     # 프레젠테이션 레이어 (API 인터페이스)
```

## 레이어별 책임

### 1. Domain Layer (도메인 레이어)

**목적**: 비즈니스 로직의 핵심, 외부 의존성 없음

- **entities/**: 도메인 엔티티
  - `Topic`: 스몰톡 주제 엔티티
- **repositories/**: 저장소 인터페이스 (추상화)
  - `TopicRepository`: 주제 저장소 인터페이스
- **services/**: 도메인 서비스 인터페이스
  - `TopicGenerator`: 주제 생성기 인터페이스

### 2. Application Layer (애플리케이션 레이어)

**목적**: Use Cases 구현, 비즈니스 흐름 관리

- **use_cases/**:
  - `GenerateTopicsUseCase`: 주제 생성 Use Case
  - `GetActiveTopicsUseCase`: 활성 주제 조회 Use Case
  - `GetTodayTopicsUseCase`: 오늘의 주제 조회 Use Case

### 3. Infrastructure Layer (인프라 레이어)

**목적**: 외부 시스템과의 통신, 인터페이스 구현

- **database/**: 데이터베이스 설정 및 모델
  - `models.py`: SQLAlchemy 모델
  - `session.py`: 세션 관리
- **repositories/**: 저장소 구현
  - `TopicRepositoryImpl`: TopicRepository 구현
- **ai_agent/**: AI Agent 구현
  - `OpenAITopicGenerator`: OpenAI 기반 주제 생성기
- **scheduler/**: 스케줄러
  - `TopicScheduler`: 주제 자동 생성 스케줄러

### 4. Presentation Layer (프레젠테이션 레이어)

**목적**: 외부 인터페이스 (REST API)

- **api/**:
  - `routes.py`: API 라우터
  - `schemas.py`: 요청/응답 스키마
  - `dependencies.py`: 의존성 주입
  - `exception_handlers.py`: 예외 처리
  - `main.py`: FastAPI 앱 설정

## 의존성 방향

```
Presentation → Application → Domain
     ↓            ↓           ↑
Infrastructure ───┘
```

- **Presentation Layer**는 **Application Layer**에 의존
- **Application Layer**는 **Domain Layer**에 의존
- **Infrastructure Layer**는 **Domain Layer**의 인터페이스를 구현
- **Domain Layer**는 외부 의존성 없음

## 주요 설계 원칙

### 1. SOLID 원칙

- **S**ingle Responsibility: 각 클래스는 하나의 책임만 가짐
- **O**pen/Closed: 인터페이스를 통해 확장 가능, 수정 불필요
- **L**iskov Substitution: 인터페이스 구현체는 상호 교체 가능
- **I**nterface Segregation: 필요한 인터페이스만 구현
- **D**ependency Inversion: 고수준 모듈은 저수준 모듈에 의존하지 않음

### 2. DRY (Don't Repeat Yourself)

- 공통 로직은 재사용 가능한 모듈로 분리
- 중복 코드 최소화

### 3. 의존성 주입

- FastAPI의 `Depends`를 통한 의존성 주입
- 테스트 시 Mock 객체 주입 가능

## 데이터 흐름

### 주제 생성 프로세스

```
1. Client Request
   ↓
2. Presentation Layer (routes.py)
   - 요청 검증
   - 의존성 주입
   ↓
3. Application Layer (GenerateTopicsUseCase)
   - 비즈니스 로직 실행
   ↓
4. Domain Layer (TopicGenerator interface)
   ↓
5. Infrastructure Layer (OpenAITopicGenerator)
   - OpenAI API 호출
   ↓
6. Domain Layer (Topic Entity)
   - 안전성 검증
   ↓
7. Infrastructure Layer (TopicRepositoryImpl)
   - 데이터베이스 저장
   ↓
8. Response to Client
```

## 테스트 전략

### 1. 단위 테스트

- **Domain Layer**: 비즈니스 로직 테스트
- **Application Layer**: Use Cases 테스트 (Mock 사용)
- **Infrastructure Layer**: 구현체 테스트

### 2. 통합 테스트

- API 엔드포인트 테스트
- 데이터베이스 통합 테스트

## 확장성 고려사항

### 1. 데이터베이스 변경

- SQLAlchemy ORM 사용으로 데이터베이스 독립성 확보
- Repository 패턴으로 데이터베이스 로직 캡슐화

### 2. AI Provider 변경

- `TopicGenerator` 인터페이스를 통해 다른 AI Provider로 교체 가능
- 예: OpenAI → Claude, Gemini 등

### 3. 스케줄러 변경

- APScheduler를 다른 스케줄러로 교체 가능
- 예: Celery, Cron 등

## 보안 고려사항

1. **API 키 관리**: 환경 변수를 통한 API 키 관리
2. **입력 검증**: Pydantic을 통한 요청 데이터 검증
3. **에러 처리**: 민감한 정보 노출 방지
4. **안전 필터링**: 민감한 주제 자동 필터링

